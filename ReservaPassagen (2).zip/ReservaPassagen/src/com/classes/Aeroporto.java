package com.classes;
import java.util.ArrayList;
public class Aeroporto {
    private ArrayList<Voo> voos;

    public Aeroporto() {
        this.voos = new ArrayList<>();
    }
    public void adicionarVoo(Voo Voos) {
        this.voos.add(Voos);
    }
    public Voo buscarVoo(String numeroVoo){
    for (Voo voo: voos){
        if (voo.getNumeroVoo().equals(numeroVoo)){
            System.out.println("Voo encontrado");
            return voo;
        }
    }

        return null;
    }

    public void removerVoo(String numeroVoo){
        Voo voo = buscarVoo(numeroVoo);

        if (voo != null){
            System.out.println("removido");
            this.voos.remove(voo);
        }

    }
    public ArrayList<Voo> getVoos() {
        return voos;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Voo voo : voos) {
            sb.append(voo.toString()).append("\n");
        }
        return sb.toString();
    }
}
