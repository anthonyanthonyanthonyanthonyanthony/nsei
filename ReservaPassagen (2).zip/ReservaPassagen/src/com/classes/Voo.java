package com.classes;

import javax.swing.*;

public class Voo {
    private String numeroVoo;
    private String origem;
    private String destino;
    private int assentosDisponiveis;



    public Voo(String numeroVoo, String origem, String Destino, int assentosDisponiveis){
        this.numeroVoo = numeroVoo;
        this.origem = origem;
        this.destino = Destino;
        this.assentosDisponiveis = assentosDisponiveis;
    }

    public String getNumeroVoo() {
        return numeroVoo;
    }
    public String getOrigem(){
        return origem;
    }
    public String getDestino(){
        return destino;
    }
    public int getAssentosDisponiveis(){
        return assentosDisponiveis;
    }
    public void realizarReserva(int quantidadeAssentos){
       if (verificarDisponibilidade(quantidadeAssentos)){
           this.assentosDisponiveis -= quantidadeAssentos;
           System.out.println("Assentos reservados");
       }
    }
    public double realizarPagamento(String tipoViagem, boolean pontosTuristicos){
        double precoBase = 2000;
        double  custoTotal = 0;
        double valorPontoTuristico = 500;

        if (tipoViagem.equals("ida")){
            custoTotal = precoBase;
        } else if(tipoViagem.equals("ida-e-volta")){
            custoTotal = precoBase * 2;
        }
        if (pontosTuristicos == true){
            custoTotal += valorPontoTuristico;
        }
        return custoTotal;

    }
    public boolean verificarDisponibilidade(int quantidadeAssentos){
        if (getAssentosDisponiveis()<quantidadeAssentos){
            System.out.println("Assentos ocupados");
            return false;
        } else {
            return true;
        }
    }
    public void imprimirPassagem() {
        // Supondo que você tenha os métodos getNumeroVoo(), getOrigem(), getDestino(), e getAssentosDisponiveis() disponíveis
        String mensagem = "Número do Voo: " + getNumeroVoo() + "\n" +
                "Origem: " + getOrigem() + "\n" +
                "Destino: " + getDestino() + "\n" +
                "Assentos Disponíveis: " + getAssentosDisponiveis();

        JOptionPane.showMessageDialog(null, mensagem, "Detalhes da Passagem", JOptionPane.INFORMATION_MESSAGE);
    }


    @Override
    public String toString() {
        return "Numero Voo: " + numeroVoo + "\n" +
                "Origem: " + origem + "\n" +
                "Destino: " +  destino + "\n" +
                "Assentos Disponiveis: " + assentosDisponiveis + "\n";
    }
}
