package exemplo;
import interfaces.TelaPrincipal;

import javax.swing.*;

// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaPrincipal(); // Cria e exibe a TelaPrincipal
        });
    }

}
