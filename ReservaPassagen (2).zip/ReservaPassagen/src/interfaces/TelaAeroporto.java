package interfaces;

import com.classes.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class TelaAeroporto {
    public Aeroporto aeroporto;

    public TelaAeroporto(Aeroporto aeroporto) {
        this.aeroporto = aeroporto;  // Recebe o objeto compartilhado
    }

    public void iniciar() {
        JFrame frame = new JFrame("Gerenciamento de Aeroportos");
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(6, 12));
        JLabel numeroVooLabel = new JLabel("Numero Voo");
        JTextField numeroVooField = new JTextField();
        JLabel origemLabel = new JLabel("Origem");
        JTextField origemField = new JTextField();
        JLabel destinoLabel = new JLabel("Destino");
        JTextField destinoField = new JTextField();
        JLabel assentosDisponiveisLabel = new JLabel("Quantidade de assentos");
        JTextField assentosDisponiveisField = new JTextField();

        inputPanel.add(numeroVooLabel);
        inputPanel.add(numeroVooField);
        inputPanel.add(origemLabel);
        inputPanel.add(origemField);
        inputPanel.add(destinoLabel);
        inputPanel.add(destinoField);
        inputPanel.add(assentosDisponiveisLabel);
        inputPanel.add(assentosDisponiveisField);

        JButton adicionarVoo = new JButton("Adicionar Voo");
        JButton buscarVoo = new JButton("Buscar Voo");
        JButton removerVoo = new JButton("Remover Voo");
        JButton voltarButton = new JButton("Voltar");  // Botão para voltar

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.CENTER_BASELINE, 14));

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(adicionarVoo);
        buttonPanel.add(buscarVoo);
        buttonPanel.add(removerVoo);
        buttonPanel.add(voltarButton);  // Adiciona o botão "Voltar"

        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Tornando a janela visível
        frame.setVisible(true);

        adicionarVoo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarVoo(numeroVooField, origemField, destinoField, assentosDisponiveisField);
                atualizarTexto(textArea);
            }
        });

        removerVoo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removerVoo(numeroVooField);
                atualizarTexto(textArea);
            }
        });

        buscarVoo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirVoo(numeroVooField, frame);
            }
        });

        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();  // Fecha a tela atual
                TelaPrincipal telaPrincipal = new TelaPrincipal();
                telaPrincipal.iniciar();  // Reabre a TelaPrincipal
            }
        });
    }

    private void adicionarVoo(JTextField numeroVooField, JTextField origemField, JTextField destinoField, JTextField assentosDisponiveisField) {
        try {
            String numeroVoo = numeroVooField.getText();
            String origem = origemField.getText();
            String destino = destinoField.getText();
            int assentosDisp = Integer.parseInt(assentosDisponiveisField.getText());

            Voo voo = aeroporto.buscarVoo(numeroVoo);

            if (voo == null) {
                voo = new Voo(numeroVoo, origem, destino, assentosDisp);
                aeroporto.adicionarVoo(voo);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerVoo(JTextField numeroVooField) {
        try {
            String numVoo = numeroVooField.getText();
            aeroporto.removerVoo(numVoo);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarTexto(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        for (Voo voo : aeroporto.getVoos()) {
            sb.append(voo.toString()).append("\n\n");
        }
        textArea.setText(sb.toString());
    }

    private void exibirVoo(JTextField numeroVooField, JFrame frame) {
        try {
            String numeroPedido = numeroVooField.getText();
            Voo voo = aeroporto.buscarVoo(numeroPedido);
            if (voo != null) {
                JOptionPane.showMessageDialog(frame, voo.toString(), "Detalhes do Pedido", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Pedido não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Número do pedido inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
