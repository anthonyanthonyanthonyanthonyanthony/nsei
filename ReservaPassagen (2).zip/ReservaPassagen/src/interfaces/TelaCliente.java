package interfaces;
import com.classes.*;

import com.classes.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaCliente {
    private Aeroporto aeroporto;
    private Voo voo;  // Assuming voo is selected or provided somehow

    public TelaCliente(Aeroporto aeroporto, Voo voo) {
        this.aeroporto = aeroporto;
        this.voo = voo;
    }
    public void iniciar() {
        JFrame frame = new JFrame("Gerenciamento de Clientes");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(7, 2));

        JLabel quantidadeAssentosLabel = new JLabel("Quantidade de Assentos:");
        JTextField quantidadeAssentosField = new JTextField();
        JLabel tipoViagemLabel = new JLabel("Tipo de Viagem (ida/ida-e-volta):");
        JTextField tipoViagemField = new JTextField();
        JLabel pontosTuristicosLabel = new JLabel("Incluir Pontos Turísticos (true/false):");
        JTextField pontosTuristicosField = new JTextField();

        JButton reservarButton = new JButton("Reservar Assentos");
        JButton pagarButton = new JButton("Realizar Pagamento");
        JButton imprimirButton = new JButton("Imprimir Passagem");

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.CENTER_BASELINE, 14));

        frame.add(quantidadeAssentosLabel);
        frame.add(quantidadeAssentosField);
        frame.add(tipoViagemLabel);
        frame.add(tipoViagemField);
        frame.add(pontosTuristicosLabel);
        frame.add(pontosTuristicosField);
        frame.add(reservarButton);
        frame.add(pagarButton);
        frame.add(imprimirButton);
        frame.add(new JScrollPane(textArea));

        frame.setVisible(true);

        reservarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int quantidadeAssentos = Integer.parseInt(quantidadeAssentosField.getText());
                    realizarReserva(quantidadeAssentos);
                    atualizarTexto(textArea);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Quantidade de assentos inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        pagarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipoViagem = tipoViagemField.getText();
                boolean pontosTuristicos = Boolean.parseBoolean(pontosTuristicosField.getText());
                realizarPagamento(tipoViagem, pontosTuristicos);
            }
        });

        imprimirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imprimirPassagem();
            }
        });


    }

    public void realizarReserva(int quantidadeAssentos) {
        if (verificarDisponibilidade(quantidadeAssentos)) {
          //  voo.setAssentosDisponiveis(voo.getAssentosDisponiveis() - quantidadeAssentos);
            JOptionPane.showMessageDialog(null, "Assentos reservados com sucesso.", "Reserva", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public boolean verificarDisponibilidade(int quantidadeAssentos) {
        if (voo.getAssentosDisponiveis() < quantidadeAssentos) {
            JOptionPane.showMessageDialog(null, "Assentos insuficientes.", "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public void realizarPagamento(String tipoViagem, boolean pontosTuristicos) {
        double precoBase = 400;
        double custoTotal = 0;
        double valorPontoTuristico = 100;

        if (tipoViagem.equalsIgnoreCase("ida")) {
            custoTotal = precoBase;
        } else if (tipoViagem.equalsIgnoreCase("ida-e-volta")) {
            custoTotal = precoBase * 2;
        }

        if (pontosTuristicos) {
            custoTotal += valorPontoTuristico;
        }

        JOptionPane.showMessageDialog(null, "Valor a pagar: R$ " + custoTotal, "Pagamento", JOptionPane.INFORMATION_MESSAGE);
    }

    public void imprimirPassagem() {
        String detalhes = "Numero do Voo: " + voo.getNumeroVoo() + "\n" +
                "Origem: " + voo.getOrigem() + "\n" +
                "Destino: " + voo.getDestino() + "\n" +
                "Assentos Disponíveis: " + voo.getAssentosDisponiveis();
        JOptionPane.showMessageDialog(null, detalhes, "Detalhes da Passagem", JOptionPane.INFORMATION_MESSAGE);
    }

    private void atualizarTexto(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        for (Voo voo : aeroporto.getVoos()) {
            sb.append(voo.toString()).append("\n\n");
        }
        textArea.setText(sb.toString());
    }
}
