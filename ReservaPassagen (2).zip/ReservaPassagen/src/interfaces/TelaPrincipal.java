package interfaces;

import com.classes.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal {
    private Aeroporto aeroporto;

    public TelaPrincipal() {
        aeroporto = new Aeroporto();  // Inicializa o objeto Aeroporto
        iniciar();
    }

    public void iniciar() {
        SwingUtilities.invokeLater(() -> {
            /*/
             cria e configura uma janela principal  com tamanho de 800x600 pixels, centraliza na tela,
              define que o fechamento da janela encerrará a aplicação, e usa o gerenciador de layout BorderLayout para organizar
              os componentes dentro da janela.

              Java JComponent A classe JComponent é a classe base de todos os componentes Swing
             */

            /*/
            O JPanel é uma classe de contêiner mais simples. Ele fornece espaço no qual um aplicativo pode anexar qualquer
            outro componente. Ele herda a classe JComponents.

            /*/ JFrame frame = new JFrame("Voo");
            frame.setSize(1000, 800);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

            // Painel para adicionar voo
            JPanel vooPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5); // Espaçamento entre os componentes

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel numeroVooLabel = new JLabel("Número Voo:");
            vooPanel.add(numeroVooLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField numeroVooField = new JTextField(15);
            vooPanel.add(numeroVooField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel origemLabel = new JLabel("Origem:");
            vooPanel.add(origemLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField origemField = new JTextField(15);
            vooPanel.add(origemField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel destinoLabel = new JLabel("Destino:");
            vooPanel.add(destinoLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField destinoField = new JTextField(15);
            vooPanel.add(destinoField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel assentosDisponiveisLabel = new JLabel("Assentos Disponíveis:");
            vooPanel.add(assentosDisponiveisLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField assentosDisponiveisField = new JTextField(15);
            vooPanel.add(assentosDisponiveisField, gbc);

            // Painel para informações do cliente e detalhes adicionais
            JPanel clientePanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbcCliente = new GridBagConstraints();
            gbcCliente.insets = new Insets(5, 5, 5, 5); // Espaçamento entre os componentes



            gbcCliente.gridx = 0;
            gbcCliente.gridy = 2;
            gbcCliente.anchor = GridBagConstraints.EAST;
            JLabel quantidadeAssentosLabel = new JLabel("Quantidade de Assentos:");
            clientePanel.add(quantidadeAssentosLabel, gbcCliente);

            gbcCliente.gridx = 1;
            gbcCliente.gridy = 2;
            gbcCliente.anchor = GridBagConstraints.WEST;
            JTextField quantidadeAssentosField = new JTextField(15);
            clientePanel.add(quantidadeAssentosField, gbcCliente);

            gbcCliente.gridx = 0;
            gbcCliente.gridy = 3;
            gbcCliente.anchor = GridBagConstraints.EAST;
            JLabel tipoViagemLabel = new JLabel("Tipo de Viagem (ida/ida-e-volta):");
            clientePanel.add(tipoViagemLabel, gbcCliente);

            gbcCliente.gridx = 1;
            gbcCliente.gridy = 3;
            gbcCliente.anchor = GridBagConstraints.WEST;
            JTextField tipoViagemField = new JTextField(15);
            clientePanel.add(tipoViagemField, gbcCliente);

            gbcCliente.gridx = 0;
            gbcCliente.gridy = 4;
            gbcCliente.anchor = GridBagConstraints.EAST;
            JLabel pontosTuristicosLabel = new JLabel("Incluir Pontos Turísticos (true/false):");
            clientePanel.add(pontosTuristicosLabel, gbcCliente);

            gbcCliente.gridx = 1;
            gbcCliente.gridy = 4;
            gbcCliente.anchor = GridBagConstraints.WEST;
            JTextField pontosTuristicosField = new JTextField(15);
            clientePanel.add(pontosTuristicosField, gbcCliente);

            // Adicionar títulos aos painéis
            vooPanel.setBorder(BorderFactory.createTitledBorder("Adicionar Voo"));
            clientePanel.setBorder(BorderFactory.createTitledBorder("Informações do Cliente"));

            JPanel inputPanel = new JPanel(new GridLayout(2, 1));
            inputPanel.add(vooPanel);
            inputPanel.add(clientePanel);



            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);
            textArea.setFont(new Font("Arial", Font.PLAIN, 14));

            JPanel textAreaPanel = new JPanel(new BorderLayout());
            textArea.setPreferredSize(new Dimension(400, 200));
            JScrollPane scrollPane = new JScrollPane(textArea);
            textAreaPanel.add(scrollPane, BorderLayout.CENTER);

            textArea.setEditable(false);
            textArea.setFont(new Font("Arial", Font.PLAIN, 14));

            textArea.setPreferredSize(new Dimension(400, 200));
            textAreaPanel.add(scrollPane, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            JButton adicionarVoo = new JButton("Adicionar Voo");
            JButton removerVoo = new JButton("Remover Voo");
            JButton exibirVoo = new JButton("Exibir Voo");
            JButton reservarButton = new JButton("Reservar Assentos");
            JButton pagarButton = new JButton("Realizar Pagamento");
            JButton imprimirButton = new JButton("Imprimir Passagem");
            buttonPanel.add(adicionarVoo);
            buttonPanel.add(removerVoo);
            buttonPanel.add(exibirVoo);
            buttonPanel.add(reservarButton);
            buttonPanel.add(pagarButton);
            buttonPanel.add(imprimirButton);

            frame.add(inputPanel, BorderLayout.NORTH);
            frame.add(textAreaPanel, BorderLayout.CENTER);
            frame.add(buttonPanel, BorderLayout.SOUTH);

            adicionarVoo.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarVoo(numeroVooField, origemField, destinoField, assentosDisponiveisField);
                    atualizarTexto(textArea);
                }
            });



            removerVoo.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    removerVoo(numeroVooField);
                    atualizarTexto(textArea);
                }
            });

            exibirVoo.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    exibirVoo(numeroVooField);
                }
            });

            reservarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        realizarReserva(quantidadeAssentosField,numeroVooField);
                        atualizarTexto(textArea);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Quantidade de assentos inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            pagarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String tipoViagem = tipoViagemField.getText();
                    boolean pontosTuristicos = Boolean.parseBoolean(pontosTuristicosField.getText());

                    realizarPagamento(tipoViagem, pontosTuristicos,numeroVooField);
                }
            });

            imprimirButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    imprimirPassagem(numeroVooField);
                }
            });

            frame.setVisible(true);
        });
    }



//Parte Aeroporto

    private void adicionarVoo(JTextField numeroVooField, JTextField origemField, JTextField destinoField, JTextField assentosDisponiveisField) {
        try {
            String numeroVoo = numeroVooField.getText();
            String origem = origemField.getText();
            String destino = destinoField.getText();
            int assentosDisp = Integer.parseInt(assentosDisponiveisField.getText());

            Voo voo = aeroporto.buscarVoo(numeroVoo);

            if (voo == null) {
                // Se o voo não estiver cadastrado, crie e adicione o novo voo
                voo = new Voo(numeroVoo, origem, destino, assentosDisp);
                aeroporto.adicionarVoo(voo);
                JOptionPane.showMessageDialog(null, "Voo adicionado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Se o voo já estiver cadastrado, exiba uma mensagem de erro
                JOptionPane.showMessageDialog(null, "Voo já cadastrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerVoo(JTextField numeroVooField) {
        try {
            String numVoo = numeroVooField.getText();
            aeroporto.removerVoo(numVoo);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarTexto(JTextArea textArea) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                StringBuilder sb = new StringBuilder();

                // Verifique se o aeroporto e a lista de voos não são nulos
                if (aeroporto != null && aeroporto.getVoos() != null) {
                    for (Voo voo : aeroporto.getVoos()) {
                        sb.append(voo.toString()).append("\n");
                    }
                } else {
                    sb.append("Nenhum voo disponível.");
                }

                textArea.setText(sb.toString());
              //  textAreaClientes.setText(sb.toString());
            }
        });
    }


    private void exibirVoo(JTextField numeroVooField) {
        try {
            String numeroPedido = numeroVooField.getText();
            Voo voo = aeroporto.buscarVoo(numeroPedido);
            if (voo != null) {
                JOptionPane.showMessageDialog(null, voo.toString(), "Detalhes do Pedido", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Pedido não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Número do pedido inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    // Parte Cliente
    public void realizarReserva(JTextField quantidadeAssentosField , JTextField numeroVooField) {
        String numeroPedido = numeroVooField.getText();
        int quantidadeAssentos = Integer.parseInt(quantidadeAssentosField.getText());
        Voo voo = aeroporto.buscarVoo(numeroPedido);

        if (verificarDisponibilidade(quantidadeAssentos, numeroVooField)) {
            JOptionPane.showMessageDialog(null, "Assentos reservados com sucesso.", "Reserva", JOptionPane.INFORMATION_MESSAGE);
            voo.realizarReserva(quantidadeAssentos);
        }
    }
    public boolean verificarDisponibilidade(int quantidadeAssentos,JTextField numeroVooField) {
        String numeroPedido = numeroVooField.getText();
        Voo voo = aeroporto.buscarVoo(numeroPedido);
        if (voo.verificarDisponibilidade(quantidadeAssentos)) {

            return true;
        }
        JOptionPane.showMessageDialog(null, "Assentos insuficientes.", "Erro", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    private void realizarPagamento(String tipoViagem, boolean pontosTuristicos,JTextField numeroVooField) {
        String numeroPedido = numeroVooField.getText();
        Voo voo = aeroporto.buscarVoo(numeroPedido);
        if (voo != null) {
            double valorPago = voo.realizarPagamento(tipoViagem, pontosTuristicos);
            JOptionPane.showMessageDialog(null, "Pagamento Feito. Valor pago: R$ " + String.format("%.2f", valorPago), "Pagamento", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Voo não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }

    }
    private void imprimirPassagem(JTextField numeroVooField) {
        String numeroPedido = numeroVooField.getText();
        Voo voo = aeroporto.buscarVoo(numeroPedido);

        voo.imprimirPassagem();
    }



}


