module ReservaPassagen {
    requires java.desktop;
}