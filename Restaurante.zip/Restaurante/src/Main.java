import com.classes.Pedido;
import com.classes.Restaurante;
import com.classes.TelaPedido;

public class Main {
    public static void main(String[] args) {
        // Criar uma instância da classe de interface gráfica
        TelaPedido telaPedido = new TelaPedido();

        // Iniciar a interface gráfica
        telaPedido.iniciar();
    }
    }

