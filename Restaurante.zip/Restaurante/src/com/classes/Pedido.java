package com.classes;
import java.util.ArrayList;

public class Pedido {
    private int numeroPedido;
    private ArrayList<String> nomeDosPratos;
    private ArrayList<Integer> quantidades;
    private ArrayList<Double> precosUnitarios;
    private double taxaEntrega = 5.0; // Exemplo de taxa de entrega

    private int numeroMesa;

    // Construtor
    public Pedido(int numero) {
        this.numeroPedido = numero;
        this.nomeDosPratos = new ArrayList<>();
        this.quantidades = new ArrayList<>();
        this.precosUnitarios = new ArrayList<>();
        this.numeroMesa = -1; // Inicializa com -1 indicando que a mesa não está reservada
    }

    // Getters e Setters
    public int getNumeroPedido() {
        return numeroPedido;
    }


    public int getNumeroMesa() {
        return numeroMesa;
    }


    public ArrayList<String> getNomeDosPratos() {
        return nomeDosPratos;
    }

    public void setNomeDosPratos(ArrayList<String> nomeDosPratos) {
        this.nomeDosPratos = nomeDosPratos;
    }

    public ArrayList<Integer> getQuantidades() {
        return quantidades;
    }

    public void setQuantidades(ArrayList<Integer> quantidades) {
        this.quantidades = quantidades;
    }

    public ArrayList<Double> getPrecosUnitarios() {
        return precosUnitarios;
    }


    // Método para adicionar um item ao pedido
    public void adicionarItem(String nomeDoPrato, int quantidade, double precoUnitario) {
        nomeDosPratos.add(nomeDoPrato);  // Adiciona o nome do prato à lista privada
        quantidades.add(quantidade);    // Adiciona a quantidade à lista privada
        precosUnitarios.add(precoUnitario); // Adiciona o preço unitário à lista privada
    }

    // Método para remover um item do pedido
    public void removerItem(String nomeDoPrato) {
        int index = nomeDosPratos.indexOf(nomeDoPrato);
        if (index != -1) {
            nomeDosPratos.remove(index);  // Remove o nome do prato da lista privada
            quantidades.remove(index);    // Remove a quantidade da lista privada
            precosUnitarios.remove(index); // Remove o preço unitário da lista privada
        }
    }

    // Método para calcular o total do pedido
    public double calcularTotalPedido() {
        double total = 0.0;
        for (int i = 0; i < nomeDosPratos.size(); i++) {
            total += quantidades.get(i) * precosUnitarios.get(i);
        }
        total += this.taxaEntrega;
        return total;
    }

    // Método para reservar a mesa
    public void reservarMesa(int numeroMesa) {
        if (this.numeroMesa == numeroMesa){
            System.out.println("Mesa invalida");
        }else {
            this.numeroMesa = numeroMesa;
        }


    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido número ").append(numeroPedido).append(":\n");
        sb.append("Mesa reservada: ").append(numeroMesa != -1 ? numeroMesa : "Não reservada").append("\n");
        sb.append("Itens:\n");
        for (int i = 0; i < nomeDosPratos.size(); i++) {
            sb.append(String.format(" - %s: %d x R$ %.2f\n", nomeDosPratos.get(i), quantidades.get(i), precosUnitarios.get(i)));
        }
        sb.append(String.format("Total: R$ %.2f\n", calcularTotalPedido()));
        return sb.toString();
    }
}