package com.classes;
import java.util.ArrayList;
public class Restaurante {
    private ArrayList<Pedido> pedidos;

    public Restaurante() {
        this.pedidos = new ArrayList<>();
    }

    public void adicionarPedido(Pedido pedido) {
        this.pedidos.add(pedido);
    }

    // Remove um pedido existente usando o número do pedido
    public void removerPedido(int numeroPedido) {
        Pedido pedido = buscarPedido(numeroPedido);
        if (pedido != null) {
            this.pedidos.remove(pedido);
        }
    }
    // Retorna a lista de todos os pedidos
    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    // Busca um pedido pelo número
    public Pedido buscarPedido(int numero) {
        for (Pedido pedido : pedidos) {
            if (pedido.getNumeroPedido() == numero) {
                return pedido;
            }
        }
        return null; // Retorna null se o pedido não for encontrado
    }
    public void exibirTodosPedidos() {
        if (pedidos.isEmpty()) {
            System.out.println("Nenhum pedido realizado.");
            return;
        }
        for (Pedido pedido : pedidos) {
            System.out.println("\n");
            System.out.println("Pedido número " + pedido.getNumeroPedido());
            System.out.println("Mesa reservada: " + (pedido.getNumeroMesa() != -1 ? pedido.getNumeroMesa() : "Não reservada"));
            System.out.println("Itens:");
            for (int i = 0; i < pedido.getNomeDosPratos().size(); i++) {
                System.out.printf(" - %s: %d x R$ %.2f\n", pedido.getNomeDosPratos().get(i), pedido.getQuantidades().get(i), pedido.getPrecosUnitarios().get(i));
            }
            System.out.printf("Total: R$ %.2f\n", pedido.calcularTotalPedido());
            System.out.println();
        }
    }
}



