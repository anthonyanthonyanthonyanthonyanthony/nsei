package com.classes;

import javax.swing.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPedido {
    private static Restaurante restaurante = new Restaurante();

    public void iniciar() {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Pedido");
            frame.setSize(800, 400);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

            // Create UI components
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            JLabel numeroPedidoLabel = new JLabel("Número do Pedido:");
            JTextField numeroPedidoField = new JTextField();
            JLabel mesaLabel = new JLabel("Número da Mesa:");
            JTextField mesaField = new JTextField();
            JLabel nomePratoLabel = new JLabel("Nome do Prato:");
            JTextField nomePratoField = new JTextField();
            JLabel quantidadeLabel = new JLabel("Quantidade:");
            JTextField quantidadeField = new JTextField();
            JLabel precoLabel = new JLabel("Preço Unitário:");
            JTextField precoField = new JTextField();


            inputPanel.add(numeroPedidoLabel);
            inputPanel.add(numeroPedidoField);
            inputPanel.add(nomePratoLabel);
            inputPanel.add(nomePratoField);
            inputPanel.add(mesaLabel);
            inputPanel.add(mesaField);
            inputPanel.add(quantidadeLabel);
            inputPanel.add(quantidadeField);
            inputPanel.add(precoLabel);
            inputPanel.add(precoField);


            JButton removeButton = new JButton("Remover Pedido");
            JButton adicionarItem = new JButton("Adicionar Item/Pedido");
            JButton removerItem = new JButton("Remover item");
            JButton viewButton = new JButton("Ver Pedido");

            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);
            textArea.setFont(new Font("Arial",Font.CENTER_BASELINE,14));

            frame.add(inputPanel, BorderLayout.NORTH);
            frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            buttonPanel.add(adicionarItem);
            buttonPanel.add(removerItem);
            buttonPanel.add(removeButton);
            buttonPanel.add(viewButton);
            frame.add(buttonPanel, BorderLayout.SOUTH);

            // Add action listeners
            adicionarItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarPedido(numeroPedidoField,nomePratoField,quantidadeField,precoField,mesaField);
                    atualizarTexto(textArea);
                }
            });
            removerItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    removerItem(numeroPedidoField,nomePratoField);
                    atualizarTexto(textArea);
                }
            });

            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    removerPedido(numeroPedidoField);
                    atualizarTexto(textArea);
                }
            });



            viewButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    exibirPedido(numeroPedidoField, frame);

                }
            });

            frame.setVisible(true);
        });
    }

    private static void adicionarPedido(JTextField numeroPedidoField, JTextField nomePratoField, JTextField quantidadeField, JTextField precoField, JTextField mesaField) {
        try {
            int numeroPedido = Integer.parseInt(numeroPedidoField.getText());
            String nomeDoPrato = nomePratoField.getText();
            int quantidade = Integer.parseInt(quantidadeField.getText());
            double precoUnitario = Double.parseDouble(precoField.getText());
            int numeroMesa = Integer.parseInt(mesaField.getText());

            Pedido pedido = restaurante.buscarPedido(numeroPedido);
            if (pedido == null) {
                pedido = new Pedido(numeroPedido);
                restaurante.adicionarPedido(pedido);
            }

            pedido.adicionarItem(nomeDoPrato, quantidade, precoUnitario);

            pedido.reservarMesa(numeroMesa);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void removerPedido(JTextField numeroPedidoField) {
        try {
            int numeroPedido = Integer.parseInt(numeroPedidoField.getText());

            restaurante.removerPedido(numeroPedido);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Número do pedido inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void exibirPedido(JTextField numeroPedidoField, JFrame frame) {
        try {

            int numeroPedido = Integer.parseInt(numeroPedidoField.getText());
            Pedido pedido = restaurante.buscarPedido(numeroPedido);
            if (pedido != null) {
                JOptionPane.showMessageDialog(frame, pedido.toString(), "Detalhes do Pedido", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Pedido não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Número do pedido inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void atualizarTexto(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        for (Pedido pedido : restaurante.getPedidos()) {
            sb.append(pedido.toString()).append("\n\n");
        }
        textArea.setText(sb.toString());
    }
    private static void removerItem(JTextField numeroPedidoField, JTextField nomePratoField){
        try {
            int numeroPedido = Integer.parseInt(numeroPedidoField.getText());
            String nomeDoPrato = nomePratoField.getText();
            Pedido pedido = restaurante.buscarPedido(numeroPedido);
            pedido.removerItem(nomeDoPrato);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Verifique os dados fornecidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }




}
