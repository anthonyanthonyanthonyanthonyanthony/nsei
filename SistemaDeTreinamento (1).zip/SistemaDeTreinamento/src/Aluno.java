import java.util.ArrayList;

// Classe Aluno
class Aluno {
    private String nome;
    private double notaAluno;

    public Aluno(String nome, double nota) {
        this.nome = nome;
        this.notaAluno = nota;
    }

    public String getNome() {
        return nome;
    }

    public double getNotaAluno() {
        return notaAluno;
    }
}