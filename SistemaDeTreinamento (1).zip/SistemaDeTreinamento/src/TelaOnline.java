import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaOnline {
    private TreinamentoOnline treinamentoOnline;

    public void iniciar(){
        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("Sistema de Treinamento Online");
            frame.setSize(1200, 600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

// Painel principal com GridBagLayout
            JPanel mainPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.BOTH; // Ajustado para preencher o espaço disponível
            gbc.weightx = 1;
            gbc.weighty = 1; // Ajustado para garantir que os painéis se expandam verticalmente

// Painel para informações do treinamento
            JPanel treinamentoPanel = new JPanel(new GridBagLayout());
            treinamentoPanel.setBorder(BorderFactory.createTitledBorder("Adicionar Curso"));

// Campos para adicionar curso
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel idLabel = new JLabel("ID:");
            treinamentoPanel.add(idLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField idField = new JTextField(15);
            treinamentoPanel.add(idField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel instrutorLabel = new JLabel("Nome do Instrutor:");
            treinamentoPanel.add(instrutorLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField instrutorField = new JTextField(15);
            treinamentoPanel.add(instrutorField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel linguagemLabel = new JLabel("Linguagem Ensinada:");
            treinamentoPanel.add(linguagemLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField linguagemField = new JTextField(15);
            treinamentoPanel.add(linguagemField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel horarioCursoLabel = new JLabel("Horário Curso:");
            treinamentoPanel.add(horarioCursoLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField horarioCursoField = new JTextField(15);
            treinamentoPanel.add(horarioCursoField, gbc);

// Atualizando para "Link de Acesso"
            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel linkAcessoLabel = new JLabel("Link de Acesso:");
            treinamentoPanel.add(linkAcessoLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 4;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField linkAcessoField = new JTextField(15);
            treinamentoPanel.add(linkAcessoField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridwidth = 2;
            gbc.anchor = GridBagConstraints.CENTER;
            JButton adicionarCursoButton = new JButton("Adicionar Curso");
            treinamentoPanel.add(adicionarCursoButton, gbc);

// Adicionar o painel de treinamento ao painel principal
            mainPanel.add(treinamentoPanel, gbc);
        // Painel para adicionar aluno

        // Campos para adicionar aluno
        JPanel alunoPanel = new JPanel(new GridLayout(0, 2, 10, 10)); // 2 colunas, espaçamento de 10px
        alunoPanel.setBorder(BorderFactory.createTitledBorder("Adicionar Aluno"));

        JLabel alunoNomeLabel = new JLabel("Nome do Aluno:");
        JTextField alunoNomeField = new JTextField(15);
        JLabel alunoNotaLabel = new JLabel("Nota do Aluno:");
        JTextField alunoNotaField = new JTextField(15);
        JLabel cursoIdLabel = new JLabel("ID do Curso:");
        JTextField cursoIdField = new JTextField(15);


        // Adiciona as labels e textfields alternadamente
        alunoPanel.add(alunoNomeLabel);
        alunoPanel.add(alunoNomeField);
        alunoPanel.add(alunoNotaLabel);
        alunoPanel.add(alunoNotaField);
        alunoPanel.add(cursoIdLabel);
        alunoPanel.add(cursoIdField);


        // Botão para adicionar aluno
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        JButton adicionarAlunoButton = new JButton("Adicionar Aluno");
        alunoPanel.add(adicionarAlunoButton, gbc);

        // Área de Texto para Mostrar Cursos e Alunos
        JPanel textPanel = new JPanel(new GridLayout(1, 2));

        JTextArea cursosTextArea = new JTextArea(20, 30);
        cursosTextArea.setEditable(false);
        JScrollPane cursosScrollPane = new JScrollPane(cursosTextArea);
        cursosScrollPane.setBorder(BorderFactory.createTitledBorder("Cursos Online"));

        JTextArea cursosAlunosTextArea = new JTextArea(20, 30);
        cursosAlunosTextArea.setEditable(false);
        JScrollPane cursosAlunosScrollPane = new JScrollPane(cursosAlunosTextArea);
        cursosAlunosScrollPane.setBorder(BorderFactory.createTitledBorder("Cursos e Alunos"));

        textPanel.add(cursosScrollPane);
        textPanel.add(cursosAlunosScrollPane);

        // Adiciona os painéis ao painel principal
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridwidth = 1;
        mainPanel.add(treinamentoPanel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        mainPanel.add(alunoPanel, gbc);

        // Adiciona o painel principal e a área de texto ao frame
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(textPanel, BorderLayout.SOUTH);
        frame.setVisible(true);

        // Inicializa o objeto vazio
// Inicializa o objeto vazio com o ID como 0 (um valor inteiro)
            treinamentoOnline = new TreinamentoOnline(0, "", "", "", 0);

        adicionarCursoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarCurso(idField, instrutorField, linguagemField, linkAcessoField, cursosTextArea,horarioCursoField);
            }
        });

        adicionarAlunoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAluno(cursoIdField, alunoNomeField, alunoNotaField, cursosAlunosTextArea);
            }
        });
    });
    }
    public void adicionarCurso(JTextField idField, JTextField instrutorField, JTextField linguagemField, JTextField linkField, JTextArea textArea,JTextField horarioField) {
        int id = Integer.parseInt(idField.getText());
        int horario = Integer.parseInt(horarioField.getText());
        // Verifica se o treinamento já existe
        TreinamentoOnline treinamentoOnline = TreinamentoOnline.buscarTreinamentoPorId(id);

        if (treinamentoOnline == null) {
            // Cria um novo treinamento se não existir
            treinamentoOnline = new TreinamentoOnline(id, instrutorField.getText(), linguagemField.getText(), linkField.getText(),horario);
        } else {
            // Atualiza o treinamento existente
            treinamentoOnline.setNomeInstrutor(instrutorField.getText());
            treinamentoOnline.setLinguagemEnsinada(linguagemField.getText());
            treinamentoOnline.setLinkAcesso(linkField.getText());
            treinamentoOnline.setId(id);
        }

        // Atualiza a visualização
        atualizarTextoCursos(textArea);
    }

    public void adicionarAluno(JTextField idField, JTextField nomeAlunoField, JTextField notaAlunoField, JTextArea textArea) {
        try {
            int id = Integer.parseInt(idField.getText());
            String nomeAluno = nomeAlunoField.getText();
            int notaAluno = Integer.parseInt(notaAlunoField.getText());

            // Verifica se o treinamento com o ID fornecido já existe
            TreinamentoOnline treinamentoOnline = TreinamentoOnline.buscarTreinamentoPorId(id);

            if (treinamentoOnline != null) {
                // Se o treinamento existir, adiciona o aluno ao treinamento
                Aluno novoAluno = new Aluno(nomeAluno, notaAluno);
                treinamentoOnline.adicionarAluno(novoAluno);

                // Atualiza a visualização do curso com os alunos
                atualizarTextoAlunos(textArea);
            } else {
                // Caso o treinamento não exista, exibe uma mensagem de erro
                JOptionPane.showMessageDialog(null, "Treinamento com ID " + id + " não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            // Exibe uma mensagem de erro se o ID ou a nota do aluno não forem válidos
            JOptionPane.showMessageDialog(null, "Por favor, insira valores numéricos válidos para ID e Nota do Aluno.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarTextoCursos(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        // Obtém todos os treinamentos e adiciona ao StringBuilder
        for (TreinamentoOnline treinamento : TreinamentoOnline.getTreinamentoOnlineMap().values()) {
            sb.append(treinamento.toString()).append("\n\n");
        }

        // Atualiza o texto da JTextArea
        textArea.setText(sb.toString());
    }
    private void atualizarTextoAlunos(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        // Iterate through all trainings and their students
        for (TreinamentoOnline treinamento : TreinamentoOnline.getTreinamentoOnlineMap().values()) {
            sb.append("Nome do Curso: ").append(treinamento.getLinguagemEnsinada()).append("\n");
            sb.append("Alunos:\n");


            // List all students in the course
            for (Aluno aluno : treinamento.getAlunos()) {

                sb.append("Nome Aluno: ").append(aluno.getNome()).append("\n");
                sb.append("Nota: ").append(aluno.getNotaAluno()).append("\n");
                sb.append("\n");


            }

            // Calculate and display the average of the students
            double media = treinamento.calcularMediaAlunos();
            sb.append("Média da Turma: ").append(String.format("%.2f", media)).append("\n\n");
        }

        // If there are no courses, show a message
        if (sb.length() == 0) {
            sb.append("Nenhum curso disponível.\n");
        }

        // Update the text area
        textArea.setText(sb.toString());
    }

}
