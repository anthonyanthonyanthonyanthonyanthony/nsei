import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPresencial {
    private TreinamentoPresencial treinamentoPresencial;

    public void iniciar() {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Sistema de Treinamento Presencial");
            frame.setSize(1200, 600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

            // Painel principal com GridBagLayout
            JPanel mainPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.BOTH; // Ajustado para preencher o espaço disponível
            gbc.weightx = 1;
            gbc.weighty = 1; // Ajustado para garantir que os painéis se expandam verticalmente

            // Painel para informações do treinamento
            JPanel treinamentoPanel = new JPanel(new GridBagLayout());
            treinamentoPanel.setBorder(BorderFactory.createTitledBorder("Adicionar Curso"));

            // Campos para adicionar curso
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel idLabel = new JLabel("ID:");
            treinamentoPanel.add(idLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField idField = new JTextField(15);
            treinamentoPanel.add(idField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel instrutorLabel = new JLabel("Nome do Instrutor:");
            treinamentoPanel.add(instrutorLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 1;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField instrutorField = new JTextField(15);
            treinamentoPanel.add(instrutorField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel linguagemLabel = new JLabel("Linguagem Ensinada:");
            treinamentoPanel.add(linguagemLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField linguagemField = new JTextField(15);
            treinamentoPanel.add(linguagemField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel horarioCursoLabel = new JLabel("Horário Curso:");
            treinamentoPanel.add(horarioCursoLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField horarioCursoField = new JTextField(15);
            treinamentoPanel.add(horarioCursoField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.anchor = GridBagConstraints.EAST;
            JLabel localLabel = new JLabel("Local Treinamento:");
            treinamentoPanel.add(localLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 4;
            gbc.anchor = GridBagConstraints.WEST;
            JTextField localField = new JTextField(15);
            treinamentoPanel.add(localField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridwidth = 2;
            gbc.anchor = GridBagConstraints.CENTER;
            JButton adicionarCursoButton = new JButton("Adicionar Curso");
            treinamentoPanel.add(adicionarCursoButton, gbc);

            // Painel para adicionar aluno

            // Campos para adicionar aluno
            JPanel alunoPanel = new JPanel(new GridLayout(0, 2, 10, 10)); // 2 colunas, espaçamento de 10px

            alunoPanel.setBorder(BorderFactory.createTitledBorder("Adicionar Aluno"));

// Campos para adicionar aluno

            JLabel alunoNomeLabel = new JLabel("Nome do Aluno:");
            JTextField alunoNomeField = new JTextField(15);
            JLabel alunoNotaLabel = new JLabel("Nota do Aluno:");
            JTextField alunoNotaField = new JTextField(15);
            JLabel cursoIdLabel = new JLabel("ID do Curso:");
            JTextField cursoIdField = new JTextField(15);



// Adiciona as labels e textfields alternadamente
            alunoPanel.add(alunoNomeLabel);
            alunoPanel.add(alunoNomeField);
            alunoPanel.add(alunoNotaLabel);
            alunoPanel.add(alunoNotaField);
            alunoPanel.add(cursoIdLabel);
            alunoPanel.add(cursoIdField);
            //botao aluno
            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridwidth = 2;
            gbc.anchor = GridBagConstraints.WEST;
            JButton adicionarAlunoButton = new JButton("Adicionar Aluno");
            alunoPanel.add(adicionarAlunoButton, gbc);
// Adiciona o botão ocupando duas colunas



            // Área de Texto para Mostrar Cursos e Alunos
            JPanel textPanel = new JPanel(new GridLayout(1, 2));

            JTextArea cursosTextArea = new JTextArea(20, 30);
            cursosTextArea.setEditable(false);
            JScrollPane cursosScrollPane = new JScrollPane(cursosTextArea);
            cursosScrollPane.setBorder(BorderFactory.createTitledBorder("Cursos"));

            JTextArea cursosAlunosTextArea = new JTextArea(20, 30);
            cursosAlunosTextArea.setEditable(false);
            JScrollPane cursosAlunosScrollPane = new JScrollPane(cursosAlunosTextArea);
            cursosAlunosScrollPane.setBorder(BorderFactory.createTitledBorder("Cursos e Alunos"));

            textPanel.add(cursosScrollPane);
            textPanel.add(cursosAlunosScrollPane);

            // Adiciona os painéis ao painel principal
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.weightx = 0.5;
            gbc.weighty = 1;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.gridwidth = 1;
            mainPanel.add(treinamentoPanel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.weightx = 0.5;
            gbc.weighty = 1;
            gbc.fill = GridBagConstraints.BOTH;
            mainPanel.add(alunoPanel, gbc);

            // Adiciona o painel principal e a área de texto ao frame
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(textPanel, BorderLayout.SOUTH);
            frame.setVisible(true);


            // Inicializa o objeto vazio
            treinamentoPresencial = new TreinamentoPresencial(0, "", "", "",0);

            adicionarCursoButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarCurso(idField,instrutorField,linguagemField,localField,horarioCursoField,cursosTextArea);

                }
            });

            adicionarAlunoButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarAluno(idField,alunoNomeField,alunoNotaField,cursosAlunosTextArea);
                }
            });


        });
    }
    public void adicionarCurso(JTextField idField, JTextField instrutorField, JTextField linguagemField, JTextField localField, JTextField horarioCursoField ,JTextArea textArea) {
        int id = Integer.parseInt(idField.getText());
        int horarioCurso  = Integer.parseInt(horarioCursoField.getText());

        // Verifica se o treinamento já existe
        TreinamentoPresencial treinamentoPresencial = TreinamentoPresencial.buscarTreinamentoPorId(id);

        if (treinamentoPresencial == null) {
            // Cria um novo treinamento se não existir
            treinamentoPresencial = new TreinamentoPresencial(id, instrutorField.getText(), linguagemField.getText(), localField.getText(),horarioCurso);
        } else {
            // Atualiza o treinamento existente
            treinamentoPresencial.setNomeInstrutor(instrutorField.getText());
            treinamentoPresencial.setLinguagemEnsinada(linguagemField.getText());
            treinamentoPresencial.setLocal(localField.getText());
            treinamentoPresencial.setHorasTreinamento(horarioCurso);
            treinamentoPresencial.setId(id);
        }

        // Atualiza a visualização
        atualizarTextoCursos(id,textArea);
    }

    public void adicionarAluno(JTextField idField, JTextField nomeAlunoField,JTextField notaAlunoField,JTextArea textArea){

        try {
            int id = Integer.parseInt(idField.getText());
            String nomeAluno = nomeAlunoField.getText();
            int notaAluno = Integer.parseInt(notaAlunoField.getText());

            // Verifica se o treinamento com o ID fornecido já existe
            TreinamentoPresencial treinamentoPresencial = TreinamentoPresencial.buscarTreinamentoPorId(id);

            if (treinamentoPresencial != null) {
                // Se o treinamento existir, adiciona o aluno ao treinamento
                Aluno novoAluno = new Aluno(nomeAluno, notaAluno);
                treinamentoPresencial.adicionarAluno(novoAluno);

                // Atualiza a visualização do curso com os alunos
                atualizarTextoAlunos(id, textArea);
            } else {
                // Caso o treinamento não exista, exibe uma mensagem de erro
                JOptionPane.showMessageDialog(null, "Treinamento com ID " + id + " não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            // Exibe uma mensagem de erro se o ID ou a nota do aluno não forem válidos
            JOptionPane.showMessageDialog(null, "Por favor, insira valores numéricos válidos para ID e Nota do Aluno.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void atualizarTextoCursos(int id, JTextArea textArea) {
        StringBuilder sb = new StringBuilder();

        // Obtém todos os treinamentos e adiciona ao StringBuilder
        for (TreinamentoPresencial treinamento : TreinamentoPresencial.getTreinamentoPresencialMap().values()) {
            sb.append(treinamento.toString()).append("\n\n");
        }

        // Atualiza o texto da JTextArea
        textArea.setText(sb.toString());
    }
    private void atualizarTextoAlunos(int id, JTextArea textArea){
        StringBuilder sb = new StringBuilder();

        // Iterate through all trainings and their students
        for (TreinamentoPresencial treinamento : TreinamentoPresencial.getTreinamentoPresencialMap().values()) {
            sb.append("Nome do Curso: ").append(treinamento.getLinguagemEnsinada()).append("\n");
            sb.append("Alunos:\n");


            // List all students in the course
            for (Aluno aluno : treinamento.getAlunos()) {

                sb.append("Nome Aluno: ").append(aluno.getNome()).append("\n");
                sb.append("Nota: ").append(aluno.getNotaAluno()).append("\n");
                sb.append("\n");


            }

            // Calculate and display the average of the students
            double media = treinamento.calcularMediaAlunos();
            sb.append("Média da Turma: ").append(String.format("%.2f", media)).append("\n\n");
        }

        // If there are no courses, show a message
        if (sb.length() == 0) {
            sb.append("Nenhum curso disponível.\n");
        }

        // Update the text area
        textArea.setText(sb.toString());
    }
}
