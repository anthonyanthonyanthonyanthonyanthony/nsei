import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal {

    public void iniciar(){
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Sistema de Treinamento");
            frame.setSize(600, 400);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

            // Painel com botões para Treinamento Presencial e Online
            JPanel buttonPanel = new JPanel();
            JButton presencialButton = new JButton("Treinamento Presencial");
            JButton onlineButton = new JButton("Treinamento Online");

            // Adicionar botões ao painel
            buttonPanel.add(presencialButton);
            buttonPanel.add(onlineButton);

            // Evento para Treinamento Presencial
            presencialButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    TelaPresencial treinamentoPresencial = new TelaPresencial();
                   treinamentoPresencial.iniciar();
                }
            });

            // Evento para Treinamento Online
            onlineButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    TelaOnline treinamentoOnline = new TelaOnline();
                    treinamentoOnline.iniciar();
                }
            });

            frame.add(buttonPanel, BorderLayout.CENTER);
            frame.setVisible(true);
        });
    }
}
