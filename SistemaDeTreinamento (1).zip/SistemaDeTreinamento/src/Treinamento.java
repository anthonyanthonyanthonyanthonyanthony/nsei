import java.util.ArrayList;
abstract class Treinamento {
    protected int id;
    protected String nomeInstrutor;
    protected String linguagemEnsinada;
    protected ArrayList<Aluno> alunos = new ArrayList<>();
    protected int cargaHoraria;

    public Treinamento(int id, String nomeInstrutor, String linguagemEnsinada) {
        this.id = id;
        this.nomeInstrutor = nomeInstrutor;
        this.linguagemEnsinada = linguagemEnsinada;
    }



    // Métodos abstratos
    public abstract boolean verificarDisponibilidade(int id);
    public abstract void definirCargaHoraria(int id, int horas);
    public abstract boolean verificarUltimoTreinamento(Aluno aluno);
    public abstract double calcularMediaAlunos();
    public int getId() {
        return id;
    }

    public String getNomeInstrutor() {
        return nomeInstrutor;
    }

    public String getLinguagemEnsinada() {
        return linguagemEnsinada;
    }

    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }
    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

}