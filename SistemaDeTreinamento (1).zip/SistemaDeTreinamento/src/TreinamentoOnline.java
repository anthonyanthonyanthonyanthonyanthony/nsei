import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

public class TreinamentoOnline extends Treinamento {
    private String linkAcesso;
    private int horasTreinamento;
    private static Map<Integer, TreinamentoOnline> treinamentoOnlineMap = new HashMap<>();

    public TreinamentoOnline(int id, String nomeInstrutor, String linguagemEnsinada, String linkAcesso, int horas) {
        super(id, nomeInstrutor, linguagemEnsinada);
        this.linkAcesso = linkAcesso;
        this.horasTreinamento = horas;
        adicionarAoMapa(id, this); // Adiciona o objeto ao mapa
    }
    public void adicionarAluno(Aluno aluno) {
        // Lógica para adicionar o aluno ao treinamento
        alunos.add(aluno);
    }
    // Método estático para obter o mapa de treinamentos online
    public static Map<Integer, TreinamentoOnline> getTreinamentoOnlineMap() {
        return treinamentoOnlineMap;
    }

    // Métodos da classe abstrata
    @Override
    public boolean verificarDisponibilidade(int id) {
        // No caso do treinamento online, a disponibilidade é verificada com base no link
        System.out.println("Verificando disponibilidade do instrutor " + nomeInstrutor + " para treinamento online.");
        return true; // Simulação de disponibilidade online
    }


    @Override
    public void definirCargaHoraria(int id, int horas) {
        System.out.println("Definindo carga horária de " + horas + " horas para o treinamento online.");
        this.horasTreinamento = horas;
    }

    @Override
    public boolean verificarUltimoTreinamento(Aluno aluno) {
        // Implementação específica para verificar se o aluno pode fazer o treinamento online
        System.out.println("Verificando último treinamento do aluno " + aluno.getNome() + " para o treinamento online.");
        return true; // Simulação de verificação
    }

    // Método estático para adicionar ou atualizar o treinamento online no mapa
    public static void adicionarAoMapa(int id, TreinamentoOnline treinamento) {
        treinamentoOnlineMap.put(id, treinamento);
    }

    @Override
    public double calcularMediaAlunos() {
        double soma = 0;
        for (Aluno aluno : alunos) {
            soma += aluno.getNotaAluno();
        }
        double media = soma / alunos.size();
        return media;
    }

    // Método estático para buscar treinamento online por ID
    public static TreinamentoOnline buscarTreinamentoPorId(int id) {
        return treinamentoOnlineMap.get(id); // Retorna o objeto correspondente ao ID
    }

    // Métodos para atualizar os atributos
    public void setLinkAcesso(String linkAcesso) {
        this.linkAcesso = linkAcesso;
    }

    public void setNomeInstrutor(String nomeInstrutor) {
        this.nomeInstrutor = nomeInstrutor;
    }

    public void setHorasTreinamento(int horasTreinamento) {
        this.horasTreinamento = horasTreinamento;
    }

    public void setLinguagemEnsinada(String linguagemEnsinada) {
        this.linguagemEnsinada = linguagemEnsinada;
    }

    public void setId(int id) {
        this.id = id;
        // Atualiza o mapa de treinamentos online
        treinamentoOnlineMap.put(id, this);
    }

    // Método para retornar informações do treinamento
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id).append("\n");
        sb.append("Nome do Instrutor: ").append(nomeInstrutor).append("\n");
        sb.append("Linguagem Ensinada: ").append(linguagemEnsinada).append("\n");
        sb.append("Link de Acesso: ").append(linkAcesso).append("\n");
        sb.append("Carga Horária: ").append(horasTreinamento).append("\n");

        return sb.toString();
    }
}