import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
public class TreinamentoPresencial extends Treinamento {
    private String local;
    private int horasTreinamento;
    private static Set<String> instrutoresOcupados = new HashSet<>();
    private static Map<Integer, TreinamentoPresencial> treinamentoPresencialMap = new HashMap<>();

    public TreinamentoPresencial(int id, String nomeInstrutor, String linguagemEnsinada, String local, int horas) {
        super(id, nomeInstrutor, linguagemEnsinada);
        this.local = local;
        this.horasTreinamento = horas;
        adicionarAoMapa(id, this); // Adiciona o objeto ao mapa

    }
    // Método estático para obter o mapa de treinamentos
    public static Map<Integer, TreinamentoPresencial> getTreinamentoPresencialMap() {
        return treinamentoPresencialMap;
    }


    // Métodos da classe abstrata
    @Override
    public boolean verificarDisponibilidade(int id) {
        if (instrutoresOcupados.contains(nomeInstrutor)) {
            System.out.println("O instrutor " + nomeInstrutor + " já está ocupado com outro treinamento.");
            return false;
        } else {
            instrutoresOcupados.add(nomeInstrutor);
            System.out.println("Instrutor " + nomeInstrutor + " disponível. Verificando disponibilidade do local: " + local);
            return true;
        }
    }

    @Override
    public void definirCargaHoraria(int id, int horas) {
        System.out.println("Definindo carga horária de " + horas + " horas para o treinamento presencial no local: " + local);
    }

    @Override
    public boolean verificarUltimoTreinamento(Aluno aluno) {
        // Implementação específica para verificar se o aluno pode fazer o treinamento
        System.out.println("Verificando último treinamento do aluno " + aluno.getNome() + " para o treinamento presencial.");
        return true; // Simulação de verificação
    }

    // Método estático para adicionar ou atualizar o treinamento no mapa
    public static void adicionarAoMapa(int id, TreinamentoPresencial treinamento) {
        treinamentoPresencialMap.put(id, treinamento);
    }

    @Override
    public double calcularMediaAlunos() {
        double soma = 0;
        for (Aluno aluno : alunos) {
            soma += aluno.getNotaAluno();
        }
        double media = soma / alunos.size();
        return media;
    }

    // Método estático para buscar treinamento por ID
    public static TreinamentoPresencial buscarTreinamentoPorId(int id) {
        return treinamentoPresencialMap.get(id); // Retorna o objeto correspondente ao ID
    }

    // Métodos para atualizar os atributos
    public void setLocal(String local) {
        this.local = local;
    }

    public void setNomeInstrutor(String nomeInstrutor) {
        this.nomeInstrutor = nomeInstrutor;
    }
    public  void setHorasTreinamento(int horasTreinamento){
        this.horasTreinamento = horasTreinamento;
    }
    public void setLinguagemEnsinada(String linguagemEnsinada) {
        this.linguagemEnsinada = linguagemEnsinada;
    }

    public void setId(int id) {
        this.id = id;
        // Atualiza o mapa de treinamentos
        treinamentoPresencialMap.put(id, this);
    }

    // Método para retornar informações do treinamento
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id).append("\n");
        sb.append("Nome do Instrutor: ").append(nomeInstrutor).append("\n");
        sb.append("Linguagem Ensinada: ").append(linguagemEnsinada).append("\n");
        sb.append("Local: ").append(local).append("\n");
        sb.append("Horario: ").append(horasTreinamento).append("\n");

        return sb.toString();
    }
}